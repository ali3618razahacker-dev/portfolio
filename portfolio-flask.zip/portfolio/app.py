import os, re, json, sqlite3, secrets, time, uuid
from functools import wraps
from datetime import datetime
from flask import (Flask, g, render_template, request, redirect, url_for,
                   session, flash, abort, get_flashed_messages)
from werkzeug.security import generate_password_hash, check_password_hash
from PIL import Image

BASE = os.path.dirname(os.path.abspath(__file__))
INST = os.path.join(BASE, "instance")
UPLOADS = os.path.join(BASE, "static", "uploads")
os.makedirs(INST, exist_ok=True); os.makedirs(UPLOADS, exist_ok=True)
DB = os.path.join(INST, "site.db")

app = Flask(__name__)
_kf = os.path.join(INST, "secret.key")
if not os.path.exists(_kf):
    open(_kf, "w").write(secrets.token_hex(32))
app.secret_key = open(_kf).read().strip()
app.config.update(MAX_CONTENT_LENGTH=6 * 1024 * 1024,
                  SESSION_COOKIE_HTTPONLY=True, SESSION_COOKIE_SAMESITE="Lax")

# ---------------------------------------------------------------- field specs
def F(name, label, type="text", **kw):
    return dict(name=name, label=label, type=type, **kw)

HEADING_FONTS = ["Bricolage Grotesque", "Fraunces", "Space Grotesk", "Syne", "Sora"]
BODY_FONTS = ["Manrope", "IBM Plex Sans", "Inter", "DM Sans"]
STATUSES = ["Shipped", "In use", "Prototype", "Pitched", "Learning project", "Hands-on"]
LEVELS = ["Beginner", "Intermediate", "Advanced"]

TABLES = {
    "projects": dict(title="Projects", label="title", fields=[
        F("title", "Title"),
        F("summary", "What it is", "textarea"),
        F("role_note", "What I personally did", "textarea",
          help="Be specific. Honest credit convinces visitors more than big claims."),
        F("tags", "Tech used (comma separated)"),
        F("status", "Status", "select", choices=STATUSES),
        F("live_url", "Live link", "url"),
        F("repo_url", "Code link", "url"),
        F("image", "Screenshot", "file"),
        F("visible", "Show on site", "bool", default=1)]),
    "skills": dict(title="Skills", label="name", fields=[
        F("name", "Skill"),
        F("category", "Group (e.g. Web, Security, Hardware)"),
        F("level", "Honest level", "select", choices=LEVELS,
          help="Beginner = followed along or flashed it. Intermediate = built working things. Advanced = shipped and maintained for real users."),
        F("evidence", "Proof: what you built or did with it", "textarea"),
        F("project_id", "Linked project", "select", choices="projects"),
        F("visible", "Show on site", "bool", default=1)]),
}

GROUPS = {
    "content": ("Content", [
        F("site_title", "Browser tab title", default="Ali Raza | Python developer in Lahore"),
        F("name", "Your name", default="Ali Raza"),
        F("role", "Role line", default="Python developer. Learning cybersecurity."),
        F("tagline", "Intro under your name", "textarea",
          default="I build web apps in Python and learn security by taking things apart on my own bench in Lahore."),
        F("photo", "Hero photo (transparent PNG/WebP works best)", "file", default="/static/img/ali.webp"),
        F("show_availability", "Show availability note", "bool", default=True),
        F("availability", "Availability note", default="Open to freelance web projects and junior roles."),
        F("about_text", "About text (blank line = new paragraph)", "textarea",
          default="I am a self-taught developer from Lahore. I started by repairing consoles and laptops, then moved into Python because I wanted to build the software side too.\n\nMy strongest interest is cybersecurity. I am still early in it, so I practise on my own hardware and network, and I list only what I have actually done."),
        F("about_facts", "Quick facts (one per line, Label: value)", "textarea",
          default="Based in: Lahore, Pakistan\nMain language: Python\nStrongest interest: Cybersecurity\nAlso: Board-level hardware repair"),
        F("skills_intro", "Skills intro", "textarea",
          default="Levels are my own honest rating. Every skill lists what I actually built or did with it."),
        F("projects_intro", "Projects intro", "textarea",
          default="Each project says what it is and what I personally did on it."),
        F("footer_text", "Footer text", default="Built with Flask in Lahore."),
    ]),
    "contact": ("Contact", [
        F("contact_title", "Contact heading", default="Let's talk"),
        F("contact_text", "Contact text", "textarea",
          default="Have a project, a job, or a question? Send a message and I will reply."),
        F("show_form", "Show contact form", "bool", default=True),
        F("email", "Email", default=""),
        F("whatsapp", "WhatsApp number (with country code, e.g. 923001234567)", default=""),
        F("github", "GitHub link", "url", default="https://github.com/ali3618razahacker-dev"),
        F("linkedin", "LinkedIn link", "url", default="https://www.linkedin.com/in/ali-raza-3a4780322"),
        F("show_email", "Show email button", "bool", default=True),
        F("show_whatsapp", "Show WhatsApp button", "bool", default=True),
        F("show_github", "Show GitHub button", "bool", default=True),
        F("show_linkedin", "Show LinkedIn button", "bool", default=True),
    ]),
    "buttons": ("Buttons & navbar", [
        F("nav_cta_show", "Show button in navbar", "bool", default=True),
        F("nav_cta_text", "Navbar button text", default="Hire me"),
        F("nav_cta_link", "Navbar button link", "url", default="#contact"),
        F("hero_btn1_show", "Show first hero button", "bool", default=True),
        F("hero_btn1_text", "First hero button text", default="See my work"),
        F("hero_btn1_link", "First hero button link", "url", default="#projects"),
        F("hero_btn2_show", "Show second hero button", "bool", default=True),
        F("hero_btn2_text", "Second hero button text", default="Get in touch"),
        F("hero_btn2_link", "Second hero button link", "url", default="#contact"),
    ]),
    "theme": ("Theme", [
        F("color_bg", "Background", "color", default="#15100B"),
        F("color_surface", "Surface", "color", default="#211812"),
        F("color_text", "Text", "color", default="#F5E9D6"),
        F("color_muted", "Muted text", "color", default="#B7A58A"),
        F("color_accent", "Accent", "color", default="#F0A030"),
        F("color_on_accent", "Text on accent", "color", default="#1A1007"),
        F("font_heading", "Heading font", "select", choices=HEADING_FONTS, default="Bricolage Grotesque"),
        F("font_body", "Body font", "select", choices=BODY_FONTS, default="Manrope"),
        F("button_style", "Button shape", "select", choices=["pill", "rounded", "square"], default="pill"),
        F("radius", "Corner radius (px, 0-40)", "int", default=14),
        F("show_glow", "Sun glow behind photo", "bool", default=True),
    ]),
}

DEFAULT_SECTIONS = [
    dict(id="about", label="About", show=True, nav=True),
    dict(id="skills", label="Skills", show=True, nav=True),
    dict(id="projects", label="Projects", show=True, nav=True),
    dict(id="contact", label="Contact", show=True, nav=True),
]
DEFAULTS = {f["name"]: f.get("default", "") for _, fl in GROUPS.values() for f in fl}
DEFAULTS["sections"] = json.dumps(DEFAULT_SECTIONS)
BOOLS = {f["name"] for _, fl in GROUPS.values() for f in fl if f["type"] == "bool"}

# ------------------------------------------------------------------ database
def db():
    if "db" not in g:
        g.db = sqlite3.connect(DB); g.db.row_factory = sqlite3.Row
    return g.db

@app.teardown_appcontext
def _close(_=None):
    d = g.pop("db", None)
    if d: d.close()

def q(sql, a=(), one=False):
    cur = db().execute(sql, a); rows = cur.fetchall(); db().commit()
    return (rows[0] if rows else None) if one else rows

def init_db():
    c = sqlite3.connect(DB)
    c.execute("CREATE TABLE IF NOT EXISTS settings (k TEXT PRIMARY KEY, v TEXT)")
    c.execute("CREATE TABLE IF NOT EXISTS messages (id INTEGER PRIMARY KEY, name TEXT, email TEXT, body TEXT, created TEXT, is_read INTEGER DEFAULT 0)")
    for t, spec in TABLES.items():
        cols = ", ".join(f'{f["name"]} ' + ("INTEGER" if f["type"] in ("bool", "int") else "TEXT")
                         for f in spec["fields"])
        c.execute(f"CREATE TABLE IF NOT EXISTS {t} (id INTEGER PRIMARY KEY, position INTEGER DEFAULT 0, {cols})")
    if not c.execute("SELECT 1 FROM settings WHERE k='seeded'").fetchone():
        seed(c)
        c.execute("INSERT INTO settings VALUES ('seeded','1')")
    if not c.execute("SELECT 1 FROM settings WHERE k='admin_hash'").fetchone():
        code = secrets.token_urlsafe(6)
        open(os.path.join(INST, "setup_code.txt"), "w").write(code)
        print(f"\n  FIRST RUN: open /admin/setup and use setup code: {code}\n")
    c.commit(); c.close()

def seed(c):
    P = [
        ("Academy LMS", "A learning management system for a local academy: courses, student accounts and lessons.",
         "Built the Flask backend and pitched it to the academy. They declined for now.", "Python, Flask", "Pitched"),
        ("Social media site", "A small social network used by family and friends through a tunnel. Never load-tested.",
         "Wrote most of the Flask backend. The frontend was mostly generated with AI tools and adapted by me.", "Python, Flask", "Prototype"),
        ("LAN chat app", "A desktop chat app with a GUI for talking across a local network.",
         "Built as a networking exercise.", "Python, Networking, GUI", "Prototype"),
        ("Retro console repair", "Board-level repairs on retro consoles at my own bench.",
         "Diagnose and fix faults using a rework station and microscope.", "Soldering, Hot air rework, Microscope", "Hands-on"),
        ("Microcontroller lab", "Open-source ESP8266 and Raspberry Pi Pico firmware flashed on my own devices to learn how they work.",
         "Flashing, testing and reading the code. The firmware is not my code.", "ESP8266, Pico, Embedded", "Learning project"),
    ]
    for i, (t, s, r, tg, st) in enumerate(P):
        c.execute("INSERT INTO projects (position,title,summary,role_note,tags,status,live_url,repo_url,image,visible) VALUES (?,?,?,?,?,?,?,?,?,1)",
                  (i, t, s, r, tg, st, "", "", ""))
    pid = lambda t: c.execute("SELECT id FROM projects WHERE title=?", (t,)).fetchone()[0]
    S = [
        ("Python", "Web & software", "Intermediate", "Wrote the backends of two Flask apps and a GUI chat app, plus automation scripts.", pid("Academy LMS")),
        ("Flask", "Web & software", "Intermediate", "Built a social site and an academy LMS. AI helped with the frontend; I wired up the backend.", pid("Social media site")),
        ("Networking", "Security", "Beginner", "Built a chat app that works across a local network.", pid("LAN chat app")),
        ("Cybersecurity", "Security", "Beginner", "Home-lab learning on my own devices and network. No certifications or professional work yet. This is my main focus.", ""),
        ("Linux", "Security", "Beginner", "Used in my home lab. Still learning.", ""),
        ("ESP32 / embedded", "Hardware", "Beginner", "Flashed and ran open-source firmware on ESP8266 and Pico boards. Not yet writing my own firmware.", pid("Microcontroller lab")),
        ("Hardware repair", "Hardware", "Intermediate", "Rework station, microscope and board-level work on retro consoles and laptops.", pid("Retro console repair")),
        ("Godot", "Other", "Beginner", "2D and 3D basics through small experiments.", ""),
        ("n8n automation", "Other", "Beginner", "Experiments with AI workflow automation.", ""),
    ]
    for i, (n, cat, lv, ev, p) in enumerate(S):
        c.execute("INSERT INTO skills (position,name,category,level,evidence,project_id,visible) VALUES (?,?,?,?,?,?,1)",
                  (i, n, cat, lv, ev, str(p)))

def settings():
    if "s" not in g:
        d = dict(DEFAULTS)
        for r in q("SELECT k,v FROM settings"):
            if r["k"] in d: d[r["k"]] = r["v"]
        for b in BOOLS:
            d[b] = d[b] in (True, "1", 1)
        g.s = d
    return g.s

def setv(k, v):
    q("INSERT INTO settings (k,v) VALUES (?,?) ON CONFLICT(k) DO UPDATE SET v=excluded.v", (k, v))

# ------------------------------------------------------------------- helpers
def clean_url(v):
    v = (v or "").strip()
    if not v or v[0] in "#/" or re.match(r"^(https?://|mailto:|tel:)", v, re.I):
        return v
    if re.match(r"^[a-z][a-z0-9+.-]*:", v, re.I):   # javascript:, data:, etc.
        return ""
    return "https://" + v

@app.template_filter("safe_url")
def safe_url(v): return clean_url(v) or "#"

@app.template_filter("paras")
def paras(v): return [p.strip() for p in re.split(r"\n\s*\n", v or "") if p.strip()]

@app.template_filter("facts")
def facts(v):
    out = []
    for ln in (v or "").splitlines():
        if ":" in ln:
            a, b = ln.split(":", 1)
            out.append((a.strip(), b.strip()))
    return out

@app.template_filter("taglist")
def taglist(v): return [t.strip() for t in (v or "").split(",") if t.strip()]

def save_upload(fl):
    ext = os.path.splitext(fl.filename)[1].lower()
    if ext not in (".png", ".jpg", ".jpeg", ".webp", ".gif"):
        flash("Only PNG, JPG, WebP or GIF images are allowed.", "error"); return None
    try:
        Image.open(fl.stream).verify(); fl.stream.seek(0)
    except Exception:
        flash("That file is not a valid image.", "error"); return None
    name = uuid.uuid4().hex + ext
    fl.save(os.path.join(UPLOADS, name))
    return "/static/uploads/" + name

def norm_choices(f):
    ch = f.get("choices", [])
    if ch == "projects":
        return [("", "None")] + [(str(r["id"]), r["title"]) for r in q("SELECT id,title FROM projects ORDER BY position,id")]
    return [(c, c) if isinstance(c, str) else c for c in ch]

def parse(f, old=None):
    n, t = f["name"], f["type"]
    if t == "bool": return 1 if request.form.get(n) else 0
    if t == "file":
        fl = request.files.get(n)
        if fl and fl.filename:
            return save_upload(fl) or (old or "")
        return "" if request.form.get("rm_" + n) else (old or "")
    v = request.form.get(n, "").strip()[:3000]
    if t == "int":
        try: return max(0, min(40, int(v)))
        except ValueError: return 14
    if t == "url": return clean_url(v)
    if t == "color": return v if re.fullmatch(r"#[0-9a-fA-F]{6}", v) else (old or f.get("default"))
    if t == "select":
        return v if v in [c[0] for c in norm_choices(f)] else (old or "")
    return v

# --------------------------------------------------------------- app plumbing
@app.before_request
def _csrf():
    if request.method == "POST":
        t = session.get("csrf", "")
        if not t or not secrets.compare_digest(t, request.form.get("csrf", "")):
            abort(400)

@app.after_request
def _headers(r):
    r.headers.update({"X-Content-Type-Options": "nosniff", "X-Frame-Options": "DENY",
                      "Referrer-Policy": "strict-origin-when-cross-origin"})
    return r

@app.context_processor
def _ctx():
    if "csrf" not in session: session["csrf"] = secrets.token_hex(16)
    unread = q("SELECT COUNT(*) c FROM messages WHERE is_read=0", one=True)["c"] if session.get("admin") else 0
    return dict(s=settings(), csrf=session["csrf"], unread=unread)

def admin_required(f):
    @wraps(f)
    def w(*a, **k):
        if not session.get("admin"): return redirect(url_for("login"))
        return f(*a, **k)
    return w

# --------------------------------------------------------------- public site
@app.route("/")
def index():
    s = settings()
    projects = q("SELECT * FROM projects WHERE visible=1 ORDER BY position,id")
    skills = q("SELECT * FROM skills WHERE visible=1 ORDER BY position,id")
    ptitle = {str(p["id"]): p["title"] for p in q("SELECT id,title FROM projects")}
    groups = {}
    for sk in skills: groups.setdefault(sk["category"] or "Other", []).append(sk)
    secs = []
    for sec in json.loads(s["sections"]):
        if not sec["show"]: continue
        if sec["id"] == "projects" and not projects: continue
        if sec["id"] == "skills" and not skills: continue
        if sec["id"] == "about" and not s["about_text"].strip(): continue
        secs.append(sec)
    links = []
    if s["show_email"] and s["email"]: links.append(("Email", "mailto:" + s["email"]))
    wa = re.sub(r"\D", "", s["whatsapp"])
    if s["show_whatsapp"] and wa: links.append(("WhatsApp", "https://wa.me/" + wa))
    if s["show_github"] and s["github"]: links.append(("GitHub", s["github"]))
    if s["show_linkedin"] and s["linkedin"]: links.append(("LinkedIn", s["linkedin"]))
    parts = s["name"].split(None, 1)
    return render_template("index.html", sections=secs, vis=[x["id"] for x in secs], projects=projects,
                           groups=groups, ptitle=ptitle, links=links, levels=LEVELS,
                           first=parts[0] if parts else "", last=parts[1] if len(parts) > 1 else "",
                           sent=get_flashed_messages(category_filter=["contact"]),
                           fh=s["font_heading"] if s["font_heading"] in HEADING_FONTS else HEADING_FONTS[0],
                           fb=s["font_body"] if s["font_body"] in BODY_FONTS else BODY_FONTS[0])

@app.route("/contact", methods=["POST"])
def contact():
    f = request.form
    if f.get("website"):                       # honeypot
        return redirect(url_for("index"))
    if time.time() - session.get("last_msg", 0) < 30:
        flash("Please wait a little before sending another message.", "contact")
        return redirect(url_for("index") + "#contact")
    name, email, body = f.get("name", "").strip()[:100], f.get("email", "").strip()[:150], f.get("message", "").strip()[:3000]
    if not name or not body or not re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+", email):
        flash("Please fill in your name, a valid email and a message.", "contact")
    else:
        q("INSERT INTO messages (name,email,body,created) VALUES (?,?,?,?)",
          (name, email, body, datetime.utcnow().strftime("%Y-%m-%d %H:%M")))
        session["last_msg"] = time.time()
        flash("Message sent. I will reply to your email.", "contact")
    return redirect(url_for("index") + "#contact")

# --------------------------------------------------------------------- admin
_fails = {}

@app.route("/admin/setup", methods=["GET", "POST"])
def setup():
    if q("SELECT 1 FROM settings WHERE k='admin_hash'", one=True): return redirect(url_for("login"))
    if request.method == "POST":
        code = open(os.path.join(INST, "setup_code.txt")).read().strip()
        pw = request.form.get("password", "")
        if not secrets.compare_digest(code, request.form.get("code", "").strip()):
            flash("Wrong setup code. It is printed in the terminal and saved in instance/setup_code.txt.", "error")
        elif len(pw) < 10:
            flash("Use at least 10 characters.", "error")
        else:
            setv("admin_hash", generate_password_hash(pw))
            os.remove(os.path.join(INST, "setup_code.txt"))
            session["admin"] = True
            return redirect(url_for("dashboard"))
    return render_template("admin/auth.html", mode="setup")

@app.route("/admin/login", methods=["GET", "POST"])
def login():
    h = q("SELECT v FROM settings WHERE k='admin_hash'", one=True)
    if not h: return redirect(url_for("setup"))
    if request.method == "POST":
        ip = request.remote_addr; n, t0 = _fails.get(ip, (0, 0))
        if n >= 5 and time.time() - t0 < 300:
            flash("Too many attempts. Try again in a few minutes.", "error")
        elif check_password_hash(h["v"], request.form.get("password", "")):
            _fails.pop(ip, None); session["admin"] = True
            return redirect(url_for("dashboard"))
        else:
            _fails[ip] = (n + 1 if time.time() - t0 < 300 else 1, time.time()); time.sleep(1)
            flash("Wrong password.", "error")
    return render_template("admin/auth.html", mode="login")

@app.route("/admin/logout", methods=["POST"])
def logout():
    session.clear(); return redirect(url_for("index"))

@app.route("/admin/password", methods=["GET", "POST"])
@admin_required
def password():
    if request.method == "POST":
        h = q("SELECT v FROM settings WHERE k='admin_hash'", one=True)["v"]
        new = request.form.get("new", "")
        if not check_password_hash(h, request.form.get("old", "")): flash("Current password is wrong.", "error")
        elif len(new) < 10: flash("Use at least 10 characters.", "error")
        else:
            setv("admin_hash", generate_password_hash(new)); flash("Password changed.", "ok")
    return render_template("admin/auth.html", mode="change")

@app.route("/admin/")
@admin_required
def dashboard():
    n = lambda t: q(f"SELECT COUNT(*) c FROM {t}", one=True)["c"]
    return render_template("admin/dashboard.html", counts=dict(projects=n("projects"), skills=n("skills"), messages=n("messages")))

@app.route("/admin/settings/<group>", methods=["GET", "POST"])
@admin_required
def edit_settings(group):
    if group not in GROUPS: abort(404)
    title, fields = GROUPS[group]
    if request.method == "POST":
        s = settings()
        for f in fields:
            v = parse(f, s[f["name"]] if f["type"] in ("file", "color") else None)
            setv(f["name"], ("1" if v else "0") if f["type"] == "bool" else str(v))
        flash("Saved.", "ok"); return redirect(request.path)
    fields = [dict(f, choices=norm_choices(f)) if f["type"] == "select" else f for f in fields]
    return render_template("admin/form.html", title=title, fields=fields, vals=settings(), group=group)

@app.route("/admin/sections", methods=["GET", "POST"])
@admin_required
def sections():
    secs = json.loads(settings()["sections"])
    if request.method == "POST":
        for sec in secs:
            sec["label"] = request.form.get("lbl_" + sec["id"], sec["label"]).strip()[:30] or sec["label"]
            sec["show"] = bool(request.form.get("show_" + sec["id"]))
            sec["nav"] = bool(request.form.get("nav_" + sec["id"]))
        mv = request.form.get("move", "")
        if ":" in mv:
            sid, d = mv.split(":"); ids = [x["id"] for x in secs]
            if sid in ids:
                i = ids.index(sid); j = i + (-1 if d == "up" else 1)
                if 0 <= j < len(secs): secs[i], secs[j] = secs[j], secs[i]
        setv("sections", json.dumps(secs)); flash("Saved.", "ok")
        return redirect(url_for("sections"))
    return render_template("admin/sections.html", secs=secs)

def spec(t):
    if t not in TABLES: abort(404)
    return TABLES[t]

@app.route("/admin/<t>")
@admin_required
def lst(t):
    sp = spec(t)
    return render_template("admin/list.html", t=t, sp=sp, rows=q(f"SELECT * FROM {t} ORDER BY position,id"))

@app.route("/admin/<t>/new", methods=["GET", "POST"])
@app.route("/admin/<t>/<int:i>/edit", methods=["GET", "POST"])
@admin_required
def edit(t, i=None):
    sp = spec(t)
    row = q(f"SELECT * FROM {t} WHERE id=?", (i,), one=True) if i else None
    if i and not row: abort(404)
    fields = [dict(f, choices=norm_choices(f)) if f["type"] == "select" else f for f in sp["fields"]]
    if request.method == "POST":
        vals = {f["name"]: parse(f, row[f["name"]] if row else None) for f in fields}
        if not str(vals[sp["fields"][0]["name"]]).strip():
            flash("The first field is required.", "error")
            return render_template("admin/form.html", title=sp["title"], fields=fields, vals=vals, group=None, t=t)
        names = list(vals)
        if i:
            q(f"UPDATE {t} SET " + ",".join(n + "=?" for n in names) + " WHERE id=?", [*vals.values(), i])
        else:
            pos = q(f"SELECT COALESCE(MAX(position),-1)+1 p FROM {t}", one=True)["p"]
            q(f"INSERT INTO {t} (position," + ",".join(names) + ") VALUES (?," + ",".join("?" * len(names)) + ")", [pos, *vals.values()])
        flash("Saved.", "ok"); return redirect(url_for("lst", t=t))
    vals = row if row else {f["name"]: f.get("default", "") for f in fields}
    return render_template("admin/form.html", title=("Edit " if i else "Add ") + sp["title"].rstrip("s").lower(),
                           fields=fields, vals=vals, group=None, t=t)

@app.route("/admin/<t>/<int:i>/<act>", methods=["POST"])
@admin_required
def row_action(t, i, act):
    spec(t)
    if act == "delete": q(f"DELETE FROM {t} WHERE id=?", (i,))
    elif act == "toggle": q(f"UPDATE {t} SET visible=1-visible WHERE id=?", (i,))
    elif act in ("up", "down"):
        ids = [r["id"] for r in q(f"SELECT id FROM {t} ORDER BY position,id")]
        if i in ids:
            a = ids.index(i); b = a + (-1 if act == "up" else 1)
            if 0 <= b < len(ids): ids[a], ids[b] = ids[b], ids[a]
        for pos, rid in enumerate(ids): q(f"UPDATE {t} SET position=? WHERE id=?", (pos, rid))
    return redirect(url_for("lst", t=t))

@app.route("/admin/messages", methods=["GET", "POST"])
@admin_required
def messages():
    if request.method == "POST":
        i = request.form.get("id", type=int)
        if request.form.get("act") == "delete": q("DELETE FROM messages WHERE id=?", (i,))
        else: q("UPDATE messages SET is_read=1 WHERE id=?", (i,))
        return redirect(url_for("messages"))
    return render_template("admin/messages.html", rows=q("SELECT * FROM messages ORDER BY id DESC"))

init_db()
if __name__ == "__main__":
    app.run(debug=False, host="127.0.0.1", port=5000)
