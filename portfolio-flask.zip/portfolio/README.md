# Ali Raza portfolio (Flask)

    pip install -r requirements.txt
    python app.py          # then open http://127.0.0.1:5000

First run prints a setup code in the terminal. Open /admin/setup, enter the code and choose your admin password.
Admin: /admin/login. Data lives in instance/site.db, uploads in static/uploads (back both up).
For public hosting: use gunicorn (gunicorn app:app) behind HTTPS.
